<html> 
<?php 
	require_once("comunes/encabezado.php"); 
	require_once("comunes/sidebar.php");	
?>
<body class="bg-stone-100">
<!-- Clase container todo debe ir dentro de contenedor -->
<article class="inicio bg-white py-8 px-4">
        <h1 class="texto-bienvenida">Hola, Bienvenido</h1>
    </article>

    <div class="fondo">
        <img src="img/logo.png" alt="">
    </div>
</body>
</html>