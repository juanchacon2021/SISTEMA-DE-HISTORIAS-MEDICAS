<div class="container">	  
<div class="modal fade" id="mostrarmodal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
   <div class="modal-dialog">
     <div class="modal-content ">
     <div class="modal-header">
        <!--<button type="button" class="close" data-dismiss="modal" aria-hidden="true" id="modalcerrar">&times;</button>-->
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="modalcerrar"></button>
            <div id="cabezerademodal">
			</div>
     </div>
     <div class="modal-body">
            <span class=" d-flex justify-content-center fas fa-check-circle" style="font-size: 80px; color: green;"></span>
            <div class=" d-flex justify-content-center font-semibold py-4" id="contenidodemodal">
			</div>    
     </div>
     <div class="modal-footer">
        <a href="#" data-dismiss="modal" class="btn btn-primary"style="background: #FF0000">
		<span class="glyphicon glyphicon-home"></span>
		Cerrar</a>
     </div>
    </div>
   </div>
</div>
</div>